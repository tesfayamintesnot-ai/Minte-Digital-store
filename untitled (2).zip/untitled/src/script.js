// Helper to open Telegram with pre-filled encoded text
function openTelegram(message) {
    const encodedMessage = encodeURIComponent(message);
    // Replace 'Minte' with your actual Telegram handle
    const telegramUrl = `https://t.me/MinteHub?text=${encodedMessage}`;
    window.open(telegramUrl, '_blank');
}
